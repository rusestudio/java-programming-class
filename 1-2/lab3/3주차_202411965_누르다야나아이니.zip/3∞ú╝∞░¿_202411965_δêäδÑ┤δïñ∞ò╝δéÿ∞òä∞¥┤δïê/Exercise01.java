package labw3;

public class Exercise01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Pizza pizza = new Pizza();
		
		pizza.order();
		pizza.order('S');
		pizza.order("치즈");
		pizza.order('L',"페퍼로니");

	}

}
